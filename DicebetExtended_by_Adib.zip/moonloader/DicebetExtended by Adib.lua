script_name('DicebetExtended')
script_author('Adib')
script_version_number(100)
script_url("https://adib23704.tk")
local scr = thisScript()
local prefix = "{FFFFFF}[ {FF0000}" .. scr.name .. " {FFFFFF}by {005522}Adib]: "

require 'moonloader'
require 'sampfuncs'
local sampev = require 'lib.samp.events'

local inicfg = require 'inicfg'
dir = getWorkingDirectory() .. "\\config\\Adib's Config\\"
dir2 = getWorkingDirectory() .. "\\config\\"
config = dir .. "" .. scr.name .. ".ini"

if not doesDirectoryExist(dir2) then createDirectory(dir2) end
if not doesDirectoryExist(dir) then createDirectory(dir) end
if not doesFileExist(config) then
    local file = io.open(config, "w")
    file:write(" ")
    file:close()
    local directIni = config
    local mainIni = inicfg.load(inicfg.load({
        main = {
            enable = true
        },
        accept = {
            enable = false,
            min = 500,
            max = 1000,
            dice = true,
            coin = false,
            msg = true
        },
        offer = {
            enable = false,
            amount = 1000,
            id = 0
        },
        logs = {
            enable = false
        }
    }, directIni))
    inicfg.save(mainIni, directIni)
end

local directIni = config
local mainIni = inicfg.load(nil, directIni)
inicfg.save(mainIni, directIni)

if mainIni.accept.dice == false and mainIni.accept.coin == false then
    mainIni.accept.dice = true
    mainIni.accept.coin = false
    inicfg.save(mainIni, directIni)
elseif mainIni.accept.dice == true and mainIni.accept.coin == true then
    mainIni.accept.dice = true
    mainIni.accept.coin = false
    inicfg.save(mainIni, directIni)
end

local waitCD = 0
local offered = false

local logDir = getWorkingDirectory() .. "\\config\\Adib's Config\\DicebetExtendedLogs\\"
local logTimestamp = tostring(os.date("%H-%M-%S_%d-%b-%y"))
local logFile = logDir .. "" .. logTimestamp .. ".txt"

local DIALOG_MAIN = 3333
local DIALOG_ACCEPT = 4444
local DIALOG_OFFER = 5555
local DIALOG_LOGS = 6666
local CAPTION = "{FF0000}" .. scr.name .. " {FFFFFF}by {005522}Adib{FFFFFF}"

function main()
    while not isSampAvailable() do wait(50) end
    offerLoop()
    sampAddChatMessage(prefix.."has been loaded! Use {FF0000}/dicex", -1)
    sampRegisterChatCommand("dicex", function()
        local string = mainIni.main.enable and "Mod State: {00FF00}Enabled" or "Mod State: Disabled"
        if mainIni.main.enable then
            string = string .. "\nConfig Auto Bet Accept System\nConfig Auto Bet Offer System\nLogs System"
        end
        sampShowDialog(DIALOG_MAIN, CAPTION .. " | Main Menu", string, "Select", "Close", 2)
    end)
    if not doesDirectoryExist(logDir) and mainIni.main.enable and mainIni.logs.enable then
        createDirectory(logDir)
    end
    if not doesFileExist(logFile) and mainIni.main.enable and mainIni.logs.enable then
        local res, id = sampGetPlayerIdByCharHandle(PLAYER_PED)
        local string = "==== DicebetExtended by Adib ====\nLog started on player name: " .. sampGetPlayerNickname(id) .. "\nTime: " .. tostring(os.date("%H:%M:%S %d/%b/%y")) .. "\n\n"
        local file = io.open(logFile, "w")
        file:write(string)
        file:close()
    end
    while true do
        local result, button, listitem, input = nil, nil, nil, nil

        result, button, listitem, input = sampHasDialogRespond(DIALOG_MAIN)
        if result then
            if button == 1 then
                if listitem == 0 then
                    mainIni.main.enable = not mainIni.main.enable
                    inicfg.save(mainIni, directIni)                   
                    dialogMain()
                elseif listitem == 1 then
                    dialogAccept()
                elseif listitem == 2 then
                    dialogOffer()
                elseif listitem == 3 then
                    dialogLogs()
                end
            end
        end
        result, button, listitem, input = sampHasDialogRespond(DIALOG_ACCEPT)
        if result then
            if button == 1 then
                if listitem == 0 then
                    mainIni.accept.enable = not mainIni.accept.enable
                    inicfg.save(mainIni, directIni)                   

                    dialogAccept()
                elseif listitem == 1 then
                    if mainIni.accept.enable then
                        sampShowDialog(DIALOG_ACCEPT + 1, CAPTION .. " | Auto Bet Accept | Minimum Amount", "Type the {FFFF00}minimum{FFFFFF} amount of bet money you want to accept automatically.\nCurrent: {00FF00}$" .. addCommas(mainIni.accept.min), "Enter", "Back", 1)
                    else
                        mainIni.accept.msg = not mainIni.accept.msg
                        inicfg.save(mainIni, directIni)                   
    
                        dialogAccept()
                    end
                elseif listitem == 2 then
                    sampShowDialog(DIALOG_ACCEPT + 2, CAPTION .. " | Auto Bet Accept | Maximum Amount", "Type the {FFFF00}maximum{FFFFFF} amount of bet money you want to accept automatically.\nCurrent: {00FF00}$" .. addCommas(mainIni.accept.max), "Enter", "Back", 1)
                elseif listitem == 3 then
                    mainIni.accept.dice = not mainIni.accept.dice
                    if mainIni.accept.coin then mainIni.accept.coin = false end
                    inicfg.save(mainIni, directIni)                   

                    dialogAccept()
                elseif listitem == 4 then
                    mainIni.accept.coin = not mainIni.accept.coin
                    if mainIni.accept.dice then mainIni.accept.dice = false end
                    inicfg.save(mainIni, directIni)                   

                    dialogAccept()
                end
            else
                dialogMain()
            end
        end
        result, button, listitem, input = sampHasDialogRespond(DIALOG_ACCEPT + 1)
        if result then
            if button == 1 then
                if tonumber(input, 10) or not input == nil then
                    input = math.floor(tonumber(input))
                    if input > mainIni.accept.max then
                        sampShowDialog(DIALOG_ACCEPT + 1, CAPTION .. " | Auto Bet Accept | Minimum Amount", "Type the {FFFF00}minimum{FFFFFF} amount of bet money you want to accept automatically.\nCurrent: {00FF00}$" .. addCommas(mainIni.accept.min) .. "\n\n{FF0000}Minimum ammount can't be higher than max ("..tostring(mainIni.accept.max)..") amount!", "Enter", "Back", 1)
                    else
                        mainIni.accept.min = input
                        inicfg.save(mainIni, directIni)
                        dialogAccept()
                    end
                else
                    sampShowDialog(DIALOG_ACCEPT + 1, CAPTION .. " | Auto Bet Accept | Minimum Amount", "Type the {FFFF00}minimum{FFFFFF} amount of bet money you want to accept automatically.\nCurrent: {00FF00}$" .. addCommas(mainIni.accept.min) .. "\n\n{FF0000}Please type a valid amount!", "Enter", "Back", 1)
                end
            else
                dialogAccept()
            end
        end
        result, button, listitem, input = sampHasDialogRespond(DIALOG_ACCEPT + 2)
        if result then
            if button == 1 then
                if tonumber(input, 10) or not input == nil then
                    input = math.floor(tonumber(input))
                    if input < mainIni.accept.min then
                        sampShowDialog(DIALOG_ACCEPT + 2, CAPTION .. " | Auto Bet Accept | Maximum Amount", "Type the {FFFF00}maximum{FFFFFF} amount of bet money you want to accept automatically.\nCurrent: {00FF00}$" .. addCommas(mainIni.accept.max) .. "\n\n{FF0000}Maximum ammount can't be lower than min ("..tostring(mainIni.accept.min)..") amount!", "Enter", "Back", 1)
                    else
                        mainIni.accept.max = input
                        inicfg.save(mainIni, directIni)
                        dialogAccept()
                    end
                else
                    sampShowDialog(DIALOG_ACCEPT + 2, CAPTION .. " | Auto Bet Accept | Maximum Amount", "Type the {FFFF00}maximum{FFFFFF} amount of bet money you want to accept automatically.\nCurrent: {00FF00}$" .. addCommas(mainIni.accept.max) .. "\n\n{FF0000}Please type a valid amount!", "Enter", "Back", 1)
                end
            else
                dialogAccept()
            end
        end
        result, button, listitem, input = sampHasDialogRespond(DIALOG_OFFER)
        if result then
            if button == 1 then
                if listitem == 0 then
                    mainIni.offer.enable = not mainIni.offer.enable
                    inicfg.save(mainIni, directIni)                   

                    dialogOffer()
                elseif listitem == 1 then
                    sampShowDialog(DIALOG_OFFER + 1, CAPTION .. " | Auto Bet Offer | Offer Amount", "Type the {FFFF00}amount{FFFFFF} of money you want to offer bet for.\nCurrent: {00FF00}$" .. addCommas(mainIni.offer.amount), "Enter", "Back", 1)
                elseif listitem == 2 then
                    sampShowDialog(DIALOG_OFFER + 2, CAPTION .. " | Auto Bet Offer | Offer to Player ID", "Type the {FFFF00}ID{FFFFFF} of the player who you want to offer bet to.\nCurrent: {00FF00}" .. tostring(mainIni.offer.id), "Enter", "Back", 1)
                end
            else
                dialogMain()
            end
        end
        result, button, listitem, input = sampHasDialogRespond(DIALOG_OFFER + 1)
        if result then
            if button == 1 then
                if tonumber(input, 10) or not input == nil then
                    input = math.floor(tonumber(input))
                    mainIni.offer.amount = input
                    inicfg.save(mainIni, directIni)
                    dialogOffer()
                else
                    sampShowDialog(DIALOG_OFFER + 1, CAPTION .. " | Auto Bet Offer | Offer Amount", "Type the {FFFF00}amount{FFFFFF} of money you want to offer bet for.\nCurrent: {00FF00}$" .. addCommas(mainIni.offer.amount) .. "\n\n{FF0000}Please type a valid amount!", "Enter", "Back", 1)
                end
            else
                dialogOffer()
            end
        end
        result, button, listitem, input = sampHasDialogRespond(DIALOG_OFFER + 2)
        if result then
            if button == 1 then
                if tonumber(input, 10) or not input == nil then
                    input = math.floor(tonumber(input))
                    if not sampIsPlayerConnected(input) then
                        sampShowDialog(DIALOG_OFFER + 2, CAPTION .. " | Auto Bet Offer | Offer to Player ID", "Type the {FFFF00}ID{FFFFFF} of the player who you want to offer bet to.\nCurrent: {00FF00}" .. tostring(mainIni.offer.id) .. "\n\n{FF0000}Invalid player ID specified!", "Enter", "Back", 1)
                    else
                        mainIni.offer.id = input
                        inicfg.save(mainIni, directIni)
                        dialogOffer()
                    end
                else
                    sampShowDialog(DIALOG_OFFER + 2, CAPTION .. " | Auto Bet Offer | Offer to Player ID", "Type the {FFFF00}ID{FFFFFF} of the player who you want to offer bet to.\nCurrent: {00FF00}" .. tostring(mainIni.offer.id) .. "\n\n{FF0000}Please enter a valid player ID", "Enter", "Back", 1)
                end
            else
                dialogOffer()
            end
        end
        result, button, listitem, input = sampHasDialogRespond(DIALOG_LOGS)
        if result then
            if button == 1 then
                if listitem == 0 then
                    mainIni.logs.enable = not mainIni.logs.enable
                    inicfg.save(mainIni, directIni)                   

                    dialogLogs()
                elseif listitem == 1 then
                    if mainIni.logs.enable then
                        os.execute('explorer "'..logDir..'"')
                    end
                end
            else
                dialogMain()
            end
        end
        if mainIni.main.enable then
            local ip, port = sampGetCurrentServerAddress()
            if ip ~= "213.32.6.232" then
                sampAddChatMessage(prefix.."This mod only works on {FF0000}Horizon Gaming RP{FFFFFF}. Unloading now..", -1)
                print("This mod only works on Horizon Gaming RP. Unloading now..")
                scr:unload()
            end
        end
        wait(1)
    end
end

function dialogMain()
    local string = mainIni.main.enable and "Mod State: {00FF00}Enabled" or "Mod State: Disabled"
    if mainIni.main.enable then
        string = string .. "\nConfig Auto Bet Accept System\nConfig Auto Bet Offer System\nLogs System"
    end
    sampShowDialog(DIALOG_MAIN, CAPTION .. " | Main Menu", string, "Select", "Close", 2)
end

function dialogAccept()
    local string = mainIni.accept.enable and "State: {00FF00}Enabled" or "State: Disabled"
    if mainIni.accept.enable then
        string = string .. "\nMin. Amount to Accept: {FF0000}$" .. addCommas(mainIni.accept.min) .. "\nMax. Amount to Accept: {FF0000}$" .. addCommas(mainIni.accept.max)
        string = string .. "\nAuto /dice: " .. (mainIni.accept.dice and "{00FF00}Enabled" or "Disabled")
        string = string .. "\nAuto /flipcoin: " .. (mainIni.accept.coin and "{00FF00}Enabled" or "Disabled")
    else
        string = string .. "\nIgnore Bet Offer Msg: " .. (mainIni.accept.msg and "{00FF00}Enabled" or "Disabled")
    end
    sampShowDialog(DIALOG_ACCEPT, CAPTION .. " | Auto Bet Accept", string, "Select", "Back", 2)
end

function dialogOffer()
    local string = mainIni.offer.enable and "State: {00FF00}Enabled" or "State: Disabled"
    if mainIni.offer.enable then
        string = string .. "\nAmount to Offer: {FF0000}$" .. addCommas(mainIni.offer.amount) .. "\nOffer to Player ID: {FF0000}" .. tostring(mainIni.offer.id) .. " (" .. sampGetPlayerNickname(mainIni.offer.id) .. ")"
    end
    sampShowDialog(DIALOG_OFFER, CAPTION .. " | Auto Bet Offer", string, "Select", "Back", 2)
end

function dialogLogs()
    local string = mainIni.logs.enable and "State: {00FF00}Enabled" or "State: Disabled"
    if mainIni.logs.enable then
        string = string .. "\nOpen logs folder"
    end
    sampShowDialog(DIALOG_LOGS, CAPTION .. " | DicebetExtended Logs", string, "Select", "Back", 2)
end

function onScriptTerminate(script, quitGame)
    if script == thisScript() then
        if mainIni.main.enable and mainIni.logs.enable then 
            local res, id = sampGetPlayerIdByCharHandle(PLAYER_PED)
            local file = io.open(logFile, "r")
            local content = file:read("*all")
            file:close()
            
            file = io.open(logFile, "w")
            file:write(content .. "\n\n\n==== DicebetExtended by Adib ====\nLog ended on player name: " .. sampGetPlayerNickname(id) .. "\nTime: " .. os.date("%H:%M:%S %d/%b/%y"))
            file:close()
        end
    end
end

function sampev.onPlayerQuit(playerId, reason)
    local res, id = sampGetPlayerIdByCharHandle(PLAYER_PED)
    if id == playerId then
        if mainIni.main.enable and mainIni.logs.enable then 
            local file = io.open(logFile, "r")
            local content = file:read("*all")
            file:close()
            
            file = io.open(logFile, "w")
            file:write(content .. "\n\n\n==== DicebetExtended by Adib ====\nLog ended on player name: " .. sampGetPlayerNickname(id) .. "\nTime: " .. os.date("%H:%M:%S %d/%b/%y"))
            file:close()
        end
    end
end

function sampev.onServerMessage(c, t)
    if mainIni.main.enable then
        if offered and mainIni.offer.enable and tonumber(c) == 869072810 and t:find("* You have cancelled: dicebet.") then
            offered = false
        end
        if tonumber(c) == -5963606 and t:find("Welcome to Horizon Roleplay,") then
            offered = false
        end
        if mainIni.offer.enable and sampIsPlayerConnected(mainIni.offer.id) then
            local name = sampGetPlayerNickname(mainIni.offer.id)
            name = name:gsub("_", " ")
            if offered and tonumber(c) == -86 and t:find(name .. " accepted your dice bet offer for") then
                offered = false
            end
        end
        if mainIni.accept.msg and not mainIni.accept.enable and tonumber(c) == -86 and t:find("wants to bet dice with you for") and t:find("type /accept dicebet to accept.") then
            sampSendChat("/cancel dicebet")
            return false
        end
        if mainIni.accept.enable then
            if tonumber(c) == -86 and t:find("wants to bet dice with you for") and t:find("type /accept dicebet to accept.") then
                local amount = tonumber(getNum(t))
                if amount < mainIni.accept.max and amount > mainIni.accept.min then
                    if mainIni.accept.dice then
                        sampSendChat("/dice")
                    elseif mainIni.accept.coin then
                        sampSendChat("/flipcoin")
                    end
                    sampSendChat("/accept dicebet")
                    sampSendChat("/accept dicebet")
                else
                    sampSendChat("/cancel dicebet")
                end
            end
        end
        if mainIni.logs.enable then
            if tonumber(c) == -86 then
                if t:find("Nobody has won the bet of") and t:find("because the dice landed on the same amount.") then
                    local amount = t:match("$(%d.-%s)")
                    amount = amount:gsub(",", "")
                    writeLog("[".. tostring(os.date("%H:%M:%S")) .. "] DRAW - Amount: " .. addCommas(amount))
                end
                if t:find(" has won the bet for ") then
                    local res, id = sampGetPlayerIdByCharHandle(PLAYER_PED)
                    local sampName = sampGetPlayerNickname(id)

                    local money = t:match("$(%d.+)%p")
                    money = money:gsub(",", "")

                    local name = t:sub(1, t:find("has")-2)
                    name = name:gsub(" ", "_")

                    if name:find(sampName) then
                        writeLog("[".. tostring(os.date("%H:%M:%S")) .. "] WIN - Amount: " .. addCommas(money))
                    else
                        writeLog("[".. tostring(os.date("%H:%M:%S")) .. "] LOSE - Amount: " .. addCommas(money))
                    end
                end
            end
        end
    end
end

function writeLog(string)
    local file = io.open(logFile, "r")
    local content = file:read("*all")
    file:close()

    file = io.open(logFile, "w")
    file:write(content .. "\n\n" .. string)
    file:close()
end

function getNum(string)
    local text
    text = string:match("$(.+),%s")
    text = text:gsub(",", "")
    return text
end

function addCommas(number)
    local i, j, minus, int, fraction = tostring(number):find('([-]?)(%d+)([.]?%d*)')
    int = int:reverse():gsub("(%d%d%d)", "%1,")
    return minus .. int:reverse():gsub("^,", "") .. fraction
end

function offerLoop()
    lua_thread.create(function()
        while true do
            if waitCD > 0 then
                waitCD = waitCD - 1000
            end
            if waitCD == 0 and sampIsLocalPlayerSpawned() and mainIni.offer.enable and not offered and getPlayerMoney(PLAYER_HANDLE) >= mainIni.offer.amount and sampIsPlayerConnected(mainIni.offer.id) then
                sampSendChat("/cancel dicebet")
                sampSendChat("/dicebet " .. mainIni.offer.id .. " " .. mainIni.offer.amount)
                offered = true
                waitCD = 14000
            end
            wait(1000)
        end
    end)
end