Hello! This is Adib, Thanks for downloading my DicebetExtended mod!

-------------------------------------------------------------
To install this mod, follow these few steps:
1. Download and install Moonloader and SAMPFUNCS latest version from "Links.txt" if you don't have.
2. Copy the "moonloader" folder to your game folder.
3. If anything needs to be replaced while copying, just replace them!

> Contact Adib23704#8947 if any help needed.
-------------------------------------------------------------

-------------------------------------------------------------
Showcase:
> https://youtu.be/AVds1whFRwU
-------------------------------------------------------------

-------------------------------------------------------------
Commands:
- /dicex
-------------------------------------------------------------

Note: THIS MOD WILL ONLY WORK ON HORIZON GAMING SERVER

-------------------------------------------------------------
Mod name: DicebetExtended
Mod Author: Adib (Adib23704#8947)
Website: https://www.adib23704.tk