> Name: HZG- Santa Helper
> Author: Adib (Adib23704#8947)
> Web: https://adib23704.github.io
> YouTube: https://youtube.com/GameBaksho


A mod for all kinds of automations and helper for HZRP's Santa Present Delivery Mini-game.

-------------------------------------------------------------

> To install this mod, follow these few steps:

 - Download and install Moonloader and SAMPFUNCS latest version if you don't have.
 - Copy the "moonloader" folder to your game folder.
 - If anything needs to be replaced while copying, just replace them!

> Contact Adib23704#8947 if any help needed.

-------------------------------------------------------------

> Commands:
- /shhelp

-------------------------------------------------------------

> Video: 
