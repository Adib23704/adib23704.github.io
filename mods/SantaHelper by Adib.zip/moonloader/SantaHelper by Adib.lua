-- Script Info
script_name('SantaHelper')
script_author('Adib')
script_version('1.0')
script_url("https://adib23704.github.io")

-- Adding libraries
require 'moonloader'
require 'sampfuncs'
local sampev = require 'lib.samp.events'
local inicfg = require "inicfg"
local vk = require "vkeys"

-- Shortcut for normal messages
scr = thisScript()
prefix = string.format("{00FF00}[ {FF0000}%s {00FF00}]{FFFFFF}: ", scr.name)

-- Setting up config file
dir = getWorkingDirectory() .. "\\config\\Adib's Config\\"
dir2 = getWorkingDirectory() .. "\\config\\"
config = dir .. "SantaHelper.ini"

if not doesDirectoryExist(dir2) then createDirectory(dir2) end
if not doesDirectoryExist(dir) then createDirectory(dir) end
if not doesFileExist(config) then
    file = io.open(config, "w")
    file:write(" ")
    file:close()
    local directIni = config
    local mainIni = inicfg.load(inicfg.load({
        stats = {
            lastlogin = 0,
            total = 0
        },
        text = {
            enable = false,
            x = 100,
            y = 100,
            color = 0xFFFFFFFF,
            size = 12
        },
        auto = {
            enable = true
        },
    }, directIni))
    
    inicfg.save(mainIni, directIni)
end
local directIni = config
local mainIni = inicfg.load(nil, directIni)
inicfg.save(mainIni, directIni)

-- Some Variables
local font = renderCreateFont("Verdana", mainIni.text.size, 0x4)
local count = 0
local reset = false
local posing = false
local taken = false

-- Main function
function main()
    while not isSampAvailable() do wait(50) end
    sampAddChatMessage(prefix.."loaded by {FF0000}Adib, {FFFFFF}Use {FF0000}/shhelp", -1)
    sampRegisterChatCommand("shhelp", function()
        sampAddChatMessage("{FFFFFF} ---> {FF0000}"..scr.name.."{FFFFFF}<---", -1)
        sampAddChatMessage("{FF0000}/sh.view - {FFFF00}View all of your counted records.", -1)
        sampAddChatMessage("{FF0000}/sh.reset - {FFFF00}Reset all of the counters.", -1)
        sampAddChatMessage("{FF0000}/sh.auto - {FFFF00}Enable / Disable auto {00ff00}/getpresent.", -1)
        sampAddChatMessage("{FF0000}/sh.text - {FFFF00}Enable / Disable counter on screen.", -1)
        if mainIni.text.enable then
            sampAddChatMessage("{FF0000}/sh.pos - {FFFF00}Change the position of the text.", -1)
            sampAddChatMessage("{FF0000}/sh.color - {FFFF00}Change the color of the text.", -1)
            sampAddChatMessage("{FF0000}/sh.size - {FFFF00}Change the size of the text.", -1)
        end
        sampAddChatMessage(" ", -1)
        sampAddChatMessage("Credits: {FF0000}Adib23704#8947", -1)
    end)
    sampRegisterChatCommand("sh.view", function()
        sampShowDialog(1001, "{FF0000}SantaHelper {FFFFFF}by {005522}Adib", "{00FF00}Current:\t\t{FFFFFF}"..tostring(count).."\n\n{00FF00}Last Login:\t\t{FFFFFF}"..tostring(mainIni.stats.lastlogin).."\n\n{00FF00}Total Count:\t\t{FFFFFF}"..tostring(mainIni.stats.total),"Ok Santa!")
    end)
    sampRegisterChatCommand("sh.reset", function ()
        sampAddChatMessage(prefix.."You're about to reset all your counted records! {FF0000}This action can't be un-done!", -1)
        sampAddChatMessage(prefix.."Type {00FF00}\"Confirm\"{FFFFFF} to reset or type {00FF00}\"Cancel\"{FFFFFF} to cancel the request.", -1)
        reset = true
    end)
    sampRegisterChatCommand("sh.auto", function()
        mainIni.auto.enable = not mainIni.auto.enable
        inicfg.save(mainIni, directIni)
        sampAddChatMessage(mainIni.auto.enable and prefix.."Auto {00FF00}Enabled!" or prefix.."Auto {FF0000}Disabled!", -1)
    end)
    sampRegisterChatCommand("sh.text", function()
        mainIni.text.enable = not mainIni.text.enable
        inicfg.save(mainIni, directIni)
        sampAddChatMessage(mainIni.text.enable and prefix.."Text {00FF00}Enabled! You've unlocked some new commands! check {FF0000}/shhelp" or prefix.."Text {FF0000}Disabled!", -1)
    end)
    sampRegisterChatCommand("sh.pos", function()
        if not mainIni.text.enable then -- Checks if text is enabled or no
            sampAddChatMessage(prefix.."Text is disabled right now. Use {FF0000}/sh.text {FFFFFF}to enable.", -1)
            return true
        end
        posing = true
        showCursor(true, true)
        sampAddChatMessage(prefix.."Cursor has been enabled! Press {00FF00}"..vk.id_to_name(VK_LBUTTON).."{FFFFFF} to update the position", -1)
    end)
    sampRegisterChatCommand("sh.color", function(args)
        if not mainIni.text.enable then -- Checks if text is enabled or no
            sampAddChatMessage(prefix.."Text is disabled right now. Use {FF0000}/sh.text {FFFFFF}to enable.", -1)
            return true
        end
        if #args < 6 or #args > 6 or string.find(args, "#") then -- Checks for hex code if its lower or higher than 6 digits or includes #.
            sampAddChatMessage(prefix.."Usage: /sh.color [Color Hex Code without \"#\"]", -1)
            return true
        end
        mainIni.text.color = "0xFF"..args -- Converts the color to ARGB
        inicfg.save(mainIni, directIni)
        sampAddChatMessage(prefix.."Color has been updated to -> {"..args.."}"..args, -1)
    end)
    sampRegisterChatCommand("sh.size", function(args)
        if not mainIni.text.enable then -- Checks if text is enabled or no
            sampAddChatMessage(prefix.."Text is disabled right now. Use {FF0000}/sh.text {FFFFFF}to enable.", -1)
            return true
        end
        if #args == 0 or tonumber(args) < 1 or tonumber(args) > 99 then -- Checks if the size input is empty or lower than 1 or higher than 100
            sampAddChatMessage(prefix.."Usage: /sh.size [1-100]", -1)
            return true
        end
        mainIni.text.size = tonumber(args)
        inicfg.save(mainIni, directIni)
        sampAddChatMessage(prefix.."Size has been updated to -> "..args, -1)
        font = renderCreateFont("Verdana", mainIni.text.size, 0x4) -- Re creates the font witht he given size
    end)
    while true do
        if mainIni.text.enable then -- If text is enabled then it will render the text on screen.
            renderFontDrawText(font, count, mainIni.text.x, mainIni.text.y, mainIni.text.color)
        end
        if posing then -- To move the text with cursor for accuracy
            local x, y = getCursorPos()
            mainIni.text.x = x
            mainIni.text.y = y
        end
        if posing and isKeyJustPressed(VK_LBUTTON) then -- Position changes on clicking LMB.
            posing = false
            local x, y = getCursorPos()
            showCursor(false, false)
            mainIni.text.x = x
            mainIni.text.y = y
            inicfg.save(mainIni, directIni)
            sampAddChatMessage(prefix.."Text position updated!", -1)
        end
        wait(1)
    end
end

function sampev.onSendChat(msg) -- For /sh.reset command.
    if reset then
        msg = string.lower(tostring(msg))
        if msg == "confirm" then
            reset = false
            sampAddChatMessage(prefix.."You've successfully reseted all of the counted records!", -1)
            mainIni.stats.lastlogin = 0
            count = 0
            mainIni.stats.total = 0
            inicfg.save(mainIni, directIni)
            return false
        elseif msg == "cancel" then
            reset = false
            sampAddChatMessage(prefix.."You've canceled resetting the counters! All values remain same.", -1)
            return false
        else
            reset = false
            sampAddChatMessage(prefix.."You've typed something else, reset request has been canceled!", -1)
            return false
        end
    end
    return true
end

function sampev.onSendPickedUpPickup(id) -- for auto /getpresent command.
    if taken == false and mainIni.auto.enable and isCharInArea2d(PLAYER_PED, -2238.369140625, -1729.8557128906, -2241.1711425781, -1734.6160888672, false) then
        sampSendChat("/getpresent")
        taken = true
    end
end

function sampev.onPlayerQuit(id, rsn)
    local _, myid = sampGetPlayerIdByCharHandle(PLAYER_PED)
    if _ and myid == id then
        taken = false
    end 
end

function sampev.onServerMessage(color, text) -- Checks for deliver msg to add 1 into the count.
    if ((tonumber(color) == 869072810) and (string.find(text, "* Thanks for delivering the present! In return, You have been placed in Santa's good books!"))) then
        count = count + 1
        mainIni.stats.total = mainIni.stats.total + 1
        inicfg.save(mainIni, directIni)
        taken = false
    end
    if(string.find(text, "You already have picked up a present. Deliver it to Pershing Square!")) then
        taken = true
    end
end

function onExitScript(quitGame) -- Adds lastlogin value upon script exit.
    mainIni.stats.lastlogin = count 
    inicfg.save(mainIni, directIni)
    taken = false
end

function sampev.onSendCommand(command)
    if taken then
        command = string.lower(command)
        if command == "/kcp" then
            taken = false
        end
    end
    return true
end

--[[
    x1 = -2238.369140625
    y1 = -1729.8557128906
    x2 = -2241.1711425781
    y2 = -1734.6160888672
    present delivery msg color = 869072810
    delivery msg = * Thanks for delivering the present! In return, You have been placed in Santa's good books!
]]--